/**
 * Export coverage data to CSV
 * @param {Array} coverage - Coverage items
 * @param {Array} campaigns - Campaign items
 * @returns {string} CSV string
 */
export const exportToCSV = (coverage, campaigns) => {
  const headers = [
    'Date', 'Title', 'Journalist', 'Publication', 'Publication Tier', 'Media Type', 'Reach', 
    'Placement Type', 'Sentiment', 'Executive Visibility', 'Target Audience',
    'Key Messages', 'LLM Visibility', 'LLM Query', 'Impact Score', 'Campaign', 'URL'
  ];
  
  const rows = coverage.map(item => [
    item.date,
    item.title,
    item.journalist,
    item.publication,
    item.publicationTier || '',
    item.mediaType || '',
    item.reach || '',
    item.placementType,
    item.sentiment,
    item.executiveVisibility?.join('; ') || 'None',
    item.targetAudience || '',
    item.keyMessages?.join('; ') || '',
    item.llmVisibility?.join('; ') || '',
    item.llmQuery || '',
    item.impactScore || '',
    item.campaignId ? campaigns.find(c => c.id === item.campaignId)?.name : '',
    item.url || ''
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
  ].join('\n');

  return csvContent;
};

/**
 * Download CSV file
 * @param {string} csvContent - CSV content string
 * @param {string} filename - Desired filename
 */
export const downloadCSV = (csvContent, filename = 'coverage-export.csv') => {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
