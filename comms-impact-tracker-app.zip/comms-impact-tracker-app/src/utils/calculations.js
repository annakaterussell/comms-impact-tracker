/**
 * Calculate impact score for a coverage item
 * @param {Object} item - Coverage item
 * @param {Array} allCoverage - All coverage items (for max reach calculation)
 * @param {Object} config - Configuration object
 * @returns {number} Impact score (0-100)
 */
export const calculateImpactScore = (item, allCoverage, config) => {
  try {
    // Reach Score (0-25) - normalized to max reach in dataset
    const maxReach = Math.max(...allCoverage.map(c => parseInt(c.reach) || 0), 1000000);
    const reachScore = ((parseInt(item.reach) || 0) / maxReach) * 25;

    // Message Alignment (0-25) - Now: ANY message inclusion gets credit, more messages = higher score
    const messageCount = item.keyMessages?.length || 0;
    const messageScore = messageCount > 0 
      ? Math.min(25, (messageCount / config.keyMessages.length) * 25 + 10) 
      : 0;
    // This gives 10 base points for including any message, plus bonus for more

    // Audience Precision (0-20) - Consumer weighted 2x higher
    let audienceScore = 0;
    if (item.targetAudience === 'Consumer') {
      audienceScore = 20; // Full points for consumer
    } else if (item.targetAudience === 'Business/Trade') {
      audienceScore = 10; // Half points for business/trade
    }

    // Sentiment Impact (0-15)
    const sentimentScore = item.sentiment === 'Positive' ? 15 : 
                          item.sentiment === 'Neutral' ? 7 : 0;

    // LLM Visibility (0-15)
    const llmScore = (item.llmVisibility?.length || 0) / config.llmModels.length * 15;

    const baseScore = reachScore + messageScore + audienceScore + sentimentScore + llmScore;

    // Multipliers
    const pubTier = config.publicationTiers[item.publicationTier] || 1.0;
    const placementMult = item.placementType === 'Proactive' ? 1.2 : 
                         item.placementType === 'Reactive' ? 1.0 : 0.9;
    const execMult = item.executiveVisibility?.includes('Interview') ? 1.5 : 
                     item.executiveVisibility?.includes('Speaking') ? 1.4 :
                     item.executiveVisibility?.includes('Quote') ? 1.2 : 1.0;

    const finalScore = Math.min(100, Math.round(baseScore * pubTier * placementMult * execMult));
    return finalScore;
  } catch (error) {
    console.error('Error calculating impact score:', error);
    return 50; // Default to medium score if calculation fails
  }
};

/**
 * Calculate statistics for coverage data
 * @param {Array} coverage - Coverage items
 * @param {Object} config - Configuration object
 * @returns {Object} Statistics object
 */
export const calculateStats = (coverage, config) => {
  const totalCoverage = coverage.length;

  // Key Message Stats
  const messageStats = config.keyMessages.map(msg => {
    const count = coverage.filter(c => c.keyMessages?.includes(msg.text)).length;
    return {
      message: msg.text,
      count,
      percentage: totalCoverage > 0 ? Math.round((count / totalCoverage) * 100) : 0
    };
  });

  // Target Audience Stats
  const audienceStats = config.targetAudiences.map(aud => {
    const count = coverage.filter(c => c.targetAudience === aud.name).length;
    return {
      audience: aud.name,
      count,
      percentage: totalCoverage > 0 ? Math.round((count / totalCoverage) * 100) : 0
    };
  });

  // Executive Stats
  const execInterviews = coverage.filter(c => c.executiveVisibility?.includes('Interview')).length;
  const execSpeaking = coverage.filter(c => c.executiveVisibility?.includes('Speaking')).length;
  const execQuotes = coverage.filter(c => c.executiveVisibility?.includes('Quote')).length;
  const execTotal = coverage.filter(c => c.executiveVisibility?.length > 0).length;
  const execRatio = totalCoverage > 0 ? Math.round((execTotal / totalCoverage) * 100) : 0;

  // Sentiment Stats
  const sentimentStats = {
    positive: coverage.filter(c => c.sentiment === 'Positive').length,
    neutral: coverage.filter(c => c.sentiment === 'Neutral').length,
    negative: coverage.filter(c => c.sentiment === 'Negative').length
  };

  // LLM Stats
  const llmStats = config.llmModels.map(model => {
    const count = coverage.filter(c => c.llmVisibility?.includes(model)).length;
    return {
      model,
      count,
      percentage: totalCoverage > 0 ? Math.round((count / totalCoverage) * 100) : 0
    };
  });

  // Publication Stats
  const publicationCounts = {};
  coverage.forEach(item => {
    if (item.publication) {
      publicationCounts[item.publication] = (publicationCounts[item.publication] || 0) + 1;
    }
  });
  const topPublications = Object.entries(publicationCounts)
    .map(([publication, count]) => ({ publication, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  return {
    messageStats,
    audienceStats,
    execStats: {
      interviews: execInterviews,
      speaking: execSpeaking,
      quotes: execQuotes,
      total: execTotal,
      ratio: execRatio
    },
    sentimentStats,
    llmStats,
    topPublications
  };
};
